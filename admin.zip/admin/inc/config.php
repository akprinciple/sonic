<?php
			$server = "localhost";
			$user = "root";
			$pwd = "";
			$db = "sonic";

			$connect = mysqli_connect($server, $user, $pwd, $db);

			//if ($connect) {
  // 	echo "connected";
   //      }
			
?>